-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 27, 2015 at 11:51 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_test`
--
CREATE DATABASE IF NOT EXISTS `library_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library_test`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE IF NOT EXISTS `authors` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=658 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `authors_books`
--

CREATE TABLE IF NOT EXISTS `authors_books` (
  `author_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors_books`
--

INSERT INTO `authors_books` (`author_id`, `book_id`, `id`) VALUES
(297, 461, 139),
(297, 462, 140),
(306, 463, 141),
(306, 464, 142),
(315, 465, 143),
(315, 466, 144),
(324, 469, 145),
(324, 470, 146),
(335, 475, 149),
(335, 476, 150),
(338, 486, 153),
(339, 487, 154),
(340, 487, 155),
(350, 490, 158),
(350, 491, 159),
(353, 501, 162),
(354, 502, 163),
(355, 502, 164),
(365, 505, 167),
(365, 506, 168),
(368, 516, 171),
(369, 517, 172),
(370, 517, 173),
(380, 520, 176),
(380, 521, 177),
(383, 531, 180),
(384, 532, 181),
(385, 532, 182),
(395, 535, 185),
(395, 536, 186),
(398, 546, 189),
(399, 547, 190),
(400, 547, 191),
(410, 550, 194),
(410, 551, 195),
(413, 561, 198),
(414, 562, 199),
(415, 562, 200),
(425, 565, 203),
(425, 566, 204),
(428, 576, 207),
(429, 577, 208),
(430, 577, 209),
(440, 580, 212),
(440, 581, 213),
(443, 591, 216),
(444, 592, 217),
(445, 592, 218),
(455, 595, 221),
(455, 596, 222),
(458, 606, 225),
(459, 607, 226),
(460, 607, 227),
(470, 610, 230),
(470, 611, 231),
(473, 621, 234),
(474, 622, 235),
(475, 622, 236),
(485, 625, 239),
(485, 626, 240),
(488, 636, 243),
(489, 637, 244),
(490, 637, 245),
(500, 640, 248),
(500, 641, 249),
(503, 651, 252),
(504, 652, 253),
(505, 652, 254),
(515, 655, 257),
(515, 656, 258),
(518, 666, 261),
(519, 667, 262),
(520, 667, 263),
(530, 670, 266),
(530, 671, 267),
(533, 681, 270),
(534, 682, 271),
(535, 682, 272),
(545, 685, 275),
(545, 686, 276),
(548, 696, 279),
(549, 697, 280),
(550, 697, 281),
(560, 700, 284),
(560, 701, 285),
(563, 711, 288),
(564, 712, 289),
(565, 712, 290),
(575, 715, 293),
(575, 716, 294),
(578, 726, 297),
(579, 727, 298),
(580, 727, 299),
(590, 730, 302),
(590, 731, 303),
(593, 741, 306),
(594, 742, 307),
(595, 742, 308),
(605, 745, 311),
(605, 746, 312),
(608, 756, 315),
(609, 757, 316),
(610, 757, 317),
(620, 760, 320),
(620, 761, 321),
(623, 771, 324),
(624, 772, 325),
(625, 772, 326),
(635, 775, 329),
(635, 776, 330),
(638, 786, 333),
(639, 787, 334),
(640, 787, 335),
(650, 790, 338),
(650, 791, 339),
(653, 801, 342),
(654, 802, 343),
(655, 802, 344);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `title` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=805 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `checkouts`
--

CREATE TABLE IF NOT EXISTS `checkouts` (
  `due_date` date DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `copy_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `copies`
--

CREATE TABLE IF NOT EXISTS `copies` (
  `book_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `patrons`
--

CREATE TABLE IF NOT EXISTS `patrons` (
  `patron_name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `authors_books`
--
ALTER TABLE `authors_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `checkouts`
--
ALTER TABLE `checkouts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `copies`
--
ALTER TABLE `copies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `patrons`
--
ALTER TABLE `patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=658;
--
-- AUTO_INCREMENT for table `authors_books`
--
ALTER TABLE `authors_books`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=347;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=805;
--
-- AUTO_INCREMENT for table `checkouts`
--
ALTER TABLE `checkouts`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=93;
--
-- AUTO_INCREMENT for table `copies`
--
ALTER TABLE `copies`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `patrons`
--
ALTER TABLE `patrons`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=195;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
